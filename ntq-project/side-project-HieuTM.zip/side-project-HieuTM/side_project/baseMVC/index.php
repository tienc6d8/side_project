<?php

session_start();

require __DIR__ . '/vendor/autoload.php';
require_once "./app/Application.php";




$myApp = new App();